package com.unla.grupo1oo22020.entities;

import java.sql.Date;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name="stock")
public class Stock {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	

	@Column(name="cantidad")
	private int cantidad;
	
	//@OneToOne(cascade = CascadeType.ALL)
	@OneToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "idProducto")
    //@JoinColumn(name = "producto_idProducto", referencedColumnName = "idProducto")
    private Producto producto;
	
	//@OneToOne(cascade = CascadeType.ALL)
	@OneToOne(cascade = CascadeType.MERGE)
  // @JoinColumn(name = "local_idLocal", referencedColumnName = "idLocal")
	//@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "idLocal")
	private Local local;
	

	public Stock() {
		super();
	}


	public Stock(long id, int cantidad, Producto producto, Local local) {
		super();
		this.id = id;
		this.cantidad = cantidad;
		this.producto = producto;
		this.local = local;
	}


	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public int getCantidad() {
		return cantidad;
	}


	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}


	public Producto getProducto() {
		return producto;
	}


	public void setProducto(Producto producto) {
		this.producto = producto;
	}


	public Local getLocal() {
		return local;
	}


	public void setLocal(Local local) {
		this.local = local;
	}

	}


	
	
