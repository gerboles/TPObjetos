package com.unla.grupo1oo22020.models;

public class StockModel {
	private int id;
	private int cantidad;
	private ProductoModel producto;
	private LocalModel local;
	
	public StockModel() {}

	public StockModel(int cantidad, ProductoModel producto, LocalModel local) {
		super();
		this.cantidad = cantidad;
		this.producto = producto;
		this.local = local;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public ProductoModel getProducto() {
		return producto;
	}

	public void setProducto(ProductoModel producto) {
		this.producto = producto;
	}

	public LocalModel getLocal() {
		return local;
	}

	public void setLocal(LocalModel local) {
		this.local = local;
	}

	
	
}
