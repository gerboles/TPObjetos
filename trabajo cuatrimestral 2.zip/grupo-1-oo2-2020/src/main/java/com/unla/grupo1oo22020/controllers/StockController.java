package com.unla.grupo1oo22020.controllers;

import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;
import java.util.*;

import com.unla.grupo1oo22020.entities.Empleado;
import com.unla.grupo1oo22020.entities.Producto;
import com.unla.grupo1oo22020.helpers.ViewRouteHelpers;
import com.unla.grupo1oo22020.models.EmpleadoModel;
import com.unla.grupo1oo22020.models.StockModel;
import com.unla.grupo1oo22020.models.LocalModel;
import com.unla.grupo1oo22020.models.LoteModel;
import com.unla.grupo1oo22020.models.ProductoModel;
import com.unla.grupo1oo22020.services.implementation.ProductoService;
import com.unla.grupo1oo22020.services.implementation.LoteService;
import com.unla.grupo1oo22020.services.implementation.LocalService;

@Controller
@RequestMapping("/stock")
public class StockController {
	
	
		@Autowired
		@Qualifier("productoService")
		private ProductoService productoService;
		
		@Autowired
		@Qualifier("localService")
		private LocalService localService;
		
		@Autowired
		@Qualifier("loteService")
		private LoteService loteService;
		
		
		
		@GetMapping("/producto")
		public ModelAndView direccion() {
			ModelAndView mAV = new ModelAndView("stock/producto");
			mAV.addObject("productos", productoService.getAll());
			return mAV;
		}
		//para probar el funcionamiento de cargar datos sin tener que direccionar a otra pagina
		//lo probe con productos y no funciono--- producto2 es el que anda
		@GetMapping("/partialprod/{id}")
		public ModelAndView partial(@PathVariable("id") int id ) {
			ModelAndView mAV = new ModelAndView("stock/partial");
			mAV.addObject("producto", productoService.findByIdProducto(id));
			return mAV;
		}
	
		
		@GetMapping("/producto2")
		public ModelAndView prod2() {
			ModelAndView mAV = new ModelAndView("stock/producto2");
			mAV.addObject("productos", productoService.getAll());
			return mAV;
		}
		//retorna todos los lotes con cantidadActual dintinta a 0 del idProducto
		@GetMapping("/producto2/{id}")
		public ModelAndView listado(@PathVariable("id") long id ) {
			ModelAndView mAV = new ModelAndView("stock/listadoStockP");
			List<LoteModel> lista= loteService.lotesPorProducto(id);
			List<LoteModel> lista2= null;
			for(LoteModel l : lista) {
				if(l.getCantidadActual()!=0) {
					lista.add(l);
				}
			}
			mAV.addObject("lista");
			return mAV;
		}
		@GetMapping("/solicitud")
		public ModelAndView sol() {
			ModelAndView mAV = new ModelAndView("stock/solicitud");
			mAV.addObject("stock", new StockModel());
			mAV.addObject("productos", productoService.getAll());
			mAV.addObject("locales", localService.getAll());
			return mAV;
		}
		
		@PostMapping("/create")
		public RedirectView create(@ModelAttribute("stock") StockModel stockModel,RedirectAttributes redirectAttrs) {
			int cantidad=0,cantLocal=0, cantLocales=0;
			long id=0;
			long idLocal = stockModel.getLocal().getIdLocal();
			long idProducto = stockModel.getProducto().getIdProducto();
			List<LoteModel> lista1=loteService.lotesPorLocal(idLocal);
			List<LoteModel> lista2 =null;
			List<LoteModel> lista3 =null;
			List<LoteModel> lista4 =null;
			
			// en el repositorio, localesPorProducto hay un fetch join con locales  y un group by idLocal
			//son todos los locales que en sus lotes poseen el producto
			List<LocalModel> locales =localService.localesPorProducto(idProducto);
			//***********************
			// ordenar la lista por proximidad
			//************************
			
			
			//sumo la cantidad que hay del producto en los lotes del local al que se iso la solicitud
			//y agrego los lotes a lista2
			for(LoteModel l : lista1) {
				if(l.getProducto().getIdProducto()==idProducto) {
				cantLocal=cantLocal+l.getCantidadActual();
				lista2.add(l);
				}
			}

			
			//sumo la cantidad que hay del producto en todos los lotes de los locales y
			//agrego los lotes a lista 4  ordenados por locales
			for(LocalModel local : locales) {
				id=local.getIdLocal();
				lista3=loteService.lotesPorLocal(id);
			for(LoteModel l : lista3) {
				if(l.getProducto().getIdProducto()==idProducto) {
				cantLocales=cantLocales+l.getCantidadActual();
				lista4.add(l);
			}
			}
			}
			
		cantidad=stockModel.getCantidad();
			// compruebo si el stock del local al que se le iso la solicitud es mayor al del pedido
				if(cantidad<cantLocal) {
					int index=0,cantLote=0;
					do {
					LoteModel lote=lista2.get(index);
			//compruebo que el lote sea menor a la cantidad solicitada y le resto la cantidad del lote y actualizo el lote
					if(lote.getCantidadActual()<cantidad) {
						cantidad=cantidad-lote.getCantidadActual();
						lote.setCantidadActual(0);
						loteService.insertOrUpdate(lote);
						// si ya la cantidad del lote supero a la cantidad solicitada pongo en 0 la cantidad solicitada 
						// y actualizo el lote
					}else  {
						cantLote=lote.getCantidadActual()-cantidad;
						lote.setCantidadActual(cantLote);
						loteService.insertOrUpdate(lote);
						cantidad=0;
					}
					index++;
					}while(cantidad!=0);
					
					// compruebo que la suma del producto disponible de todos los lotes de los locales
					// sea mayor a la suma socisitada
			}else if(cantidad<cantLocales) {
				int index=0,cantLote=0;
				do {
				//lista 4 posee todos los lotes del producto ordenados por local
				LoteModel lote=lista4.get(index);
				if(lote.getCantidadActual()<cantidad) {
					cantidad=cantidad-lote.getCantidadActual();
					lote.setCantidadActual(0);
					loteService.insertOrUpdate(lote);
				}else  {
				 cantLote=lote.getCantidadActual()-cantidad;
					lote.setCantidadActual(cantLote);
					loteService.insertOrUpdate(lote);
					cantidad=0;
				}
				index++;
			
				}while(cantidad!=0);
			}else {
				// LA CANTIDAD SOLICITADA SUPERA A LA SUMA DE TODOS LOS LOTES
		
		}
			return new RedirectView(ViewRouteHelpers.INDEX);
}
}