package com.unla.grupo1oo22020.services;

public interface ISolicitudStockService {

}
