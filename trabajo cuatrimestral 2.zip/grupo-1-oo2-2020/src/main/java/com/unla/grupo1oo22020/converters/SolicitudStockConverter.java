package com.unla.grupo1oo22020.converters;

public class SolicitudStockConverter {

}
