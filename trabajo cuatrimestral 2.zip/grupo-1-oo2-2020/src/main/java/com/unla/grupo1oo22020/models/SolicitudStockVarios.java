package com.unla.grupo1oo22020.models;
import java.util.*;
public class SolicitudStockVarios {
   private int id;
   private ProductoModel prod;
   private Set<LocalModel> lstLocales;
}
